import turtle as t

t.Screen()
t.setup(600,500,100,200)
t.bgcolor('blue')
t.title('Movements in Turtle Graphics')
t.forward(200)
t.backward(300)
t.done()
t.bye()
