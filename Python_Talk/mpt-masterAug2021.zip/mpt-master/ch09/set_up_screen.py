import turtle as t

t.Screen()
t.setup(600,500,100,200)
t.bgcolor('SpringGreen3')
t.title('Setting Up A Screen with Turtle Graphics')
t.done()
t.bye() 
