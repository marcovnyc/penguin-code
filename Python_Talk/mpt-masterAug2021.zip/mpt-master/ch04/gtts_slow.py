import os

os.system('gtts-cli --nocheck --slow "hello, how are you?" | mpg123 -q -')
