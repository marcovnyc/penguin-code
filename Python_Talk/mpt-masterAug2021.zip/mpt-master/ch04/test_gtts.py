import os

os.system('gtts-cli --nocheck "hello, how are you?" | mpg123 -q -')
