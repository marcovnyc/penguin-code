from gtts import gTTS
tts = gTTS('replace this file with a country music song', lang='en')
tts.save('country.mp3')