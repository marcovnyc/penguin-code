# Make sure you put hello.mp3 in the same folder as this script
from playsound import playsound

playsound("hello.mp3")

