# The file create_local_module.py must be in the same folder as this script
import create_local_module

print(create_local_module.team_sales(2, 0.05, 0.1))
print(create_local_module.team_sales(1, 0.08, 0.1))
print(create_local_module.team_sales(2, 0.02, 0.08))

