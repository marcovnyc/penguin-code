for n in (1, 2, 3):
    if n == 2:
        break
    print(n)
print('finished')

