lst = [1, "a", "hello"]
lst.append(2) 
print(lst)




