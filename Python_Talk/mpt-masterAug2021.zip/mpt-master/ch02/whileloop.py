n = 0
while n < 3:
    n = n + 1
    print(n)
print('finished')
