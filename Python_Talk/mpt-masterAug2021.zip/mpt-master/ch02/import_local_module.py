# The file create_local_module.py must be in the same folder as this script
from create_local_module import team_sales

print(team_sales(100, 160, 200))
print(team_sales(200, 250, 270))
print(team_sales(150, 120, 200))
