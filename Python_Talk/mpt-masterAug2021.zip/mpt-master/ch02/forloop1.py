for n in (1, 2, 3):
    if n == 2:
        continue
    print(n)
print('finished')
