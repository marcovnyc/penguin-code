def team_sales(sales1, sales2, sales3):
   sales = sales1 + sales2 + sales3
   return sales
print(team_sales(100, 150, 120))
