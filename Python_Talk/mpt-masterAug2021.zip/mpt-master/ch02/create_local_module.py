# This creates a local module to be imported to other scripts
def team_sales(sales1, sales2, sales3):
    sales = sales1 + sales2 + sales3
    return sales
