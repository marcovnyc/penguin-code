for n in range(3):
    n = n + 1
    print(n)
print('finished')
