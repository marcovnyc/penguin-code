for letter in ("A", "B", "C"):
    for num in (1, 2):
        print(f"this is {letter}{num}")
