
from .mysr import voice_to_text
from .mysay import print_say

''' Starting in Chapter 7, add the following five lines in this file 
from .mywakeup import wakeup
from .mytimer import timer
from .myalarm import alarm
from .myjoke import joke
from .myemail import email
'''

''' Starting in Chapter 8, add the following line in this file 
from .myknowall import know_all
'''

''' In Chapter 17, add the following in this file
from .mymusic import music_play, music_stop
from .mynews import news_brief, news_stop
from .myradio import live_radio, radio_stop
from .myttt import ttt
from .myconn import conn
from .mystock import stock_market, stock_price
from .mytranslate import voice_translate
'''
