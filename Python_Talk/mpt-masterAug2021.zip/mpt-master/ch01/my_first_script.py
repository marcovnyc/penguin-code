# -*- coding: utf-8 -*-
"""
Created on Fri Apr 16 14:49:19 2021

@author: hlliu2
"""

print("This is my very first Python script!")

print("This is my second Python message!")
